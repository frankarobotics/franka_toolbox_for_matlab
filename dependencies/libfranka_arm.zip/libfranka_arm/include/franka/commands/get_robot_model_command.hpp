#pragma once

#include <string>

namespace franka {

struct GetRobotModelResult {
  std::string robot_model_urdf;
};

}  // namespace franka
